# -*- coding: utf-8 -*-
"""
Created on Mon Aug 27 17:08:42 2018

@author: tb267
"""

from . import datastructure
from . import streams

import numpy as np
import scipy.signal as signal
import scipy.stats as stats
import datetime
import time

MESSAGE = ''

#%% Main data acquisition function
def log_data(settings, test_name=None, rec=None, output=None):
    '''Acquire one block of time-domain data and return it as a DataSet.

    Two call modes depending on ``settings.pretrig_samples``:

    * **No pretrigger** (``pretrig_samples is None``): starts / reuses
      a stream, sleeps for ``settings.stored_time`` seconds, and
      returns the most recent ``stored_time * fs`` samples from the
      circular buffer. If ``output`` is supplied it is played in
      parallel (soundcard play is blocking; NI play is non-blocking
      and synchronized against ``stored_time`` via WaitUntilTaskDone).
    * **Pretrigger armed** (``pretrig_samples`` set): waits up to
      ``settings.pretrig_timeout`` seconds for the monitored channel
      to cross ``settings.pretrig_threshold``. On trigger, returns a
      window of ``stored_time * fs`` samples straddling the trigger
      sample so that ``pretrig_samples`` of pre-trigger data appears
      at the start of the returned buffer. **On timeout with no
      trigger** the function does not raise — it falls back to
      returning the tail of the buffer (same as the no-pretrigger
      path) with ``trigger_detected = False``.

    Parameters
    ----------
    settings : MySettings
        Acquisition configuration. See `pydvma.options.MySettings`.
    test_name : str or None
        Stored on the returned `TimeData` for labelling.
    rec : Recorder-like or None
        Ignored. Retained for backward compatibility with callers (the
        GUI's ``LogDataThread``) that still pass a cached recorder.
        ``log_data`` now always rebuilds the stream via
        ``streams.start_stream(settings)`` so that switching device or
        backend between calls doesn't leave a stale recorder.
    output : ndarray (N_samples, output_channels) or None
        Optional playback signal **in volts**. For NI it's passed
        through as-is (must stay within ±``output_VmaxNI``). For
        soundcard it's divided by ``output_VmaxSC`` to recover the ±1
        normalised units sounddevice expects.

    Returns
    -------
    DataSet
        A DataSet containing one TimeData **in volts**. If
        ``settings.use_output_as_ch0`` is True and ``output`` was
        supplied, the output signal is prepended as an extra channel.

    Notes
    -----
    A clipping warning is printed when ``|data| > 0.95 * Vmax``
    anywhere in the capture, where ``Vmax`` is ``VmaxNI`` on the NI
    path and ``VmaxSC`` on the soundcard path. Both default to
    behaviour equivalent to the old ±1-normalised check when the user
    hasn't overridden them.

    Pretrigger positioning (both backends, identical logic)
    -------------------------------------------------------
    On a successful trigger, the returned buffer is
    ``stored_time * fs`` samples long and the first sample exceeding
    ``pretrig_threshold`` sits at exactly index ``pretrig_samples`` —
    samples ``[0, pretrig_samples)`` are pre-trigger context. See
    `streams.Recorder` for the state machine that gives this
    invariant.

    ``pretrig_samples`` is capped at ``chunk_size`` (validated at
    call-time with a ``ValueError``); the recorder only retains that
    much pre-trigger context. Larger windows require a larger
    ``chunk_size``.

    On a **trigger timeout** (``pretrig_timeout`` elapses with nothing
    above threshold), the function does not raise — it returns the
    tail of the buffer (same shape as the no-pretrigger path), leaves
    ``trigger_detected`` False, and prints a "not detected" message.
    '''
    global MESSAGE

    # Defence-in-depth guard: MySettings.__init__ already rejects this
    # at construction time, but callers routinely mutate settings in
    # place (e.g. s.pretrig_samples = N after construction). Re-check
    # here so the buffer-geometry invariant holds at the point of use.
    # See the "Trigger / pretrigger state machine" block on
    # `streams.Recorder` for why the ceiling is `chunk_size`.
    if (settings.pretrig_samples is not None
            and settings.pretrig_samples > settings.chunk_size):
        raise ValueError(
            'pretrig_samples ({}) must not exceed chunk_size ({}). '
            'The pretrigger buffer only retains chunk_size samples of '
            'context before the trigger; increase chunk_size (or '
            'reduce pretrig_samples) to fit.'
            .format(settings.pretrig_samples, settings.chunk_size)
        )

    # Always rebuild the stream. `streams.REC` can be None when a prior
    # `end_stream()` fired (e.g. on device switch) even though the caller
    # still holds a stale `rec` reference; rebuilding keeps them in sync.
    streams.start_stream(settings)
    rec = streams.REC

    streams.REC.trigger_detected = False
    
    # Stream is slightly longer than settings.stored_time, so need to add delay
    # from initialisation to allow stream to fill up and prevent zeros at start
    # of logged data.
    time.sleep(2*settings.chunk_size/settings.fs)
    t = datetime.datetime.now()
    timestring = '_'+str(t.year)+'_'+str(t.month)+'_'+str(t.day)+'_at_'+str(t.hour)+'_'+str(t.minute)+'_'+str(t.second)
    
    if settings.pretrig_samples is None:

        MESSAGE = 'Logging data for {} seconds.\n'.format(settings.stored_time)
        print(MESSAGE)
        
        
        # basic way to control logging time: won't be precise time from calling function
        # also won't be exactly synced to output signal
        if output is not None:
            s = output_signal(settings,output)
            # rec.write(output.astype('float32'))
        
        if (settings.device_driver != 'soundcard') or (output is None): # soundcard output is blocking via sd.OutputStream.write; nidaq and mock are non-blocking
            time.sleep(settings.stored_time)
        
            
        # make copy of data
        stored_time_data_copy = np.copy(streams.REC.stored_time_data)
        number_samples = int(streams.REC.settings.stored_time * streams.REC.settings.fs)
        
        stored_time_data_copy = stored_time_data_copy[-number_samples:,:]
        MESSAGE += 'Logging complete.\n'
        print(MESSAGE)

        if output is not None:
            if settings.output_device_driver == 'soundcard':
                s.stop()
                s.close()
            if settings.output_device_driver in ('nidaq', 'mock'):
                s.WaitUntilTaskDone(settings.stored_time+5)
                s.StopTask()



    else:
        streams.REC.__init__(settings) # zeros buffers so looks for trigger in fresh data
        streams.REC.trigger_detected = False # somehow this can be true even after previous call
        streams.REC.trigger_first_detected_message = True
        
        MESSAGE = 'Waiting for trigger on channel {}.\n'.format(settings.pretrig_channel)
        print(MESSAGE)
        
        start_output_flag = True
        t0 = time.time()
        while (time.time()-t0 < settings.pretrig_timeout) and not streams.REC.trigger_detected:
            if (output is not None) and (start_output_flag == True): # start output within loop, but only once!
                time.sleep(1)
                MESSAGE = 'Starting output signal.\n'
                print(MESSAGE)
                s = output_signal(settings,output)
                # rec.write(output.astype('float32'))
                start_output_flag = False

            time.sleep(0.2)
        if (time.time()-t0 > settings.pretrig_timeout):
            MESSAGE = 'Trigger not detected within timeout of {} seconds.\n'.format(settings.pretrig_timeout)
            print(MESSAGE)
        
        # make copy of data
        stored_time_data_copy = np.copy(streams.REC.stored_time_data)
        trigger_check = stored_time_data_copy[(settings.chunk_size):(2*settings.chunk_size),settings.pretrig_channel]
        hits = np.where(np.abs(trigger_check) > settings.pretrig_threshold)[0]
        number_samples = int(settings.stored_time * settings.fs)
        if len(hits) == 0:
            # Timeout expired with no trigger detected — return the tail of
            # the buffer rather than crashing with IndexError.
            stored_time_data_copy = stored_time_data_copy[-number_samples:, :]
        else:
            detected_sample = settings.chunk_size + hits[0]
            start_index = detected_sample - settings.pretrig_samples
            end_index   = start_index + number_samples
            stored_time_data_copy = stored_time_data_copy[start_index:end_index,:]
        streams.REC.trigger_detected = False # don't start stream again until sorted out trigger detection
        
        MESSAGE = 'Logging complete.\n'
        print(MESSAGE)

        if output is not None:
            if settings.output_device_driver == 'soundcard':
                s.stop()
                s.close()
            if settings.output_device_driver in ('nidaq', 'mock'):
                s.WaitUntilTaskDone(settings.stored_time+5)
                s.StopTask()

    # make into dataset
    fs = settings.fs
    n_samp = len(stored_time_data_copy[:,0])
    dt = 1/fs
    t_samp = n_samp*dt
    time_axis = np.linspace(0,(n_samp-1)/n_samp * settings.stored_time,n_samp)
    
    if (output is not None) and (settings.use_output_as_ch0 == True):
        stored_output = np.zeros((n_samp,len(output[0,:])))
        n_start = settings.pretrig_samples
        if n_start is None:
            n_start = 0
        n_end = np.copy(n_samp)
        if len(output[:,0]) >= (n_end-n_start):
            stored_output[n_start:n_end,:] = output[:n_end-n_start,:]
        elif len(output[:,0]) < (n_end-n_start):
            stored_output[n_start:len(output[:,0])+n_start,:] = output[:,:]
            
        stored_time_data_copy = np.concatenate((stored_output,stored_time_data_copy),axis=1)

    # Carry per-channel calibration through to the TimeData. With
    # default ``channel_sensitivities = 1.0`` this is just ones (no
    # calibration applied), matching pre-refactor behaviour. With a
    # 100 mV/g accelerometer (sensitivity = 0.1 V/g) the cal_factor
    # is 10, so plots and modal fits read in g.
    cal_factors = 1.0 / np.asarray(settings.channel_sensitivities, dtype=float)
    if (output is not None) and settings.use_output_as_ch0:
        # The output channel was prepended; it has no measured
        # sensitivity, so its cal_factor is 1.0 (passes through).
        n_out = stored_time_data_copy.shape[1] - len(cal_factors)
        cal_factors = np.concatenate((np.ones(n_out), cal_factors))

    timedata = datastructure.TimeData(
        time_axis, stored_time_data_copy, settings,
        timestamp=t, timestring=timestring, test_name=test_name,
        channel_cal_factors=cal_factors,
    )
    
    
    dataset  = datastructure.DataSet()
    dataset.add_to_dataset(timedata)
    
    # Check for clipping. Data is now in volts, so compare against the
    # effective full-scale (VmaxNI for nidaq, VmaxSC for soundcard). Any
    # sample within 5 % of the rail gets flagged.
    clip_threshold = 0.95 * settings.input_vmax()
    if np.any(np.abs(stored_time_data_copy) > clip_threshold):
        MESSAGE += 'WARNING: Data may be clipped'
        print(MESSAGE)
    
    
    return dataset
    


#def log_data_with_output(settings, output,test_name=None, rec=None):
#
    
    # # call log_data function
    # dataset = log_data(settings, test_name, rec)
    
    # # call output_signal function
    # output_signal(settings,output)
    
    # return dataset
    


def output_signal(settings, output):
    '''Play ``output`` (in volts) on the configured AO device.

    For soundcard, divides by ``output_VmaxSC`` to recover the ±1
    normalised float sounddevice expects. For NI, the voltage array
    is passed straight through to `setup_output_NI` (the AO task is
    configured with ±``output_VmaxNI`` rails).
    '''
    if settings.output_device_driver == 'soundcard':
        s = streams.setup_output_soundcard(settings)
        # sounddevice expects ±1 normalised float32. `output` is in
        # volts, so divide by the calibration constant before writing.
        data = (output / settings.output_VmaxSC).astype('float32')
        s.write(data)
        return s

    elif settings.output_device_driver == 'nidaq':
        s = streams.setup_output_NI(settings, output)
        s.StartTask()
        return s

    elif settings.output_device_driver == 'mock':
        # No-op output for the hardware-free test backend. Returns a
        # stream-like with the same surface as the NI adapter so
        # log_data's cleanup branches can call StartTask/StopTask/etc.
        s = streams.setup_output_mock(settings, output)
        s.StartTask()
        return s

    else:
        print('device_driver not recognised')
        return None


def signal_generator(settings,sig='gaussian',T=1,amplitude=0.1,f=None,selected_channels='all'):
    """Create an output-ready waveform.

    ``amplitude`` is in **volts** — the generated signal is bounded to
    ±``amplitude`` and, as a safety ceiling, clipped to
    ±``settings.output_vmax()`` (i.e. output_VmaxNI on the NI path,
    output_VmaxSC on the soundcard path). Returns ``(t, y)`` where
    ``y`` is shape ``(N, output_channels)`` in volts, ready to hand to
    `log_data(..., output=y)` or `output_signal`.
    """
    global MESSAGE
    if selected_channels == 'all':
        selected_channels = np.arange(0,settings.output_channels)

    # initiate variables
    t = np.arange(0,T,1/settings.output_fs)
    N_per_channel = np.size(t)
    y = np.zeros((N_per_channel,settings.output_channels))
    win = np.ones((N_per_channel,1))
    T_ramp = np.min([T/10,0.1])
    N_ramp = int(T_ramp*settings.output_fs)
    win[0:N_ramp,0] = 0.5*(1-np.cos(np.arange(0,N_ramp)/N_ramp*np.pi))
    win[-N_ramp:,0] = 0.5*(1+np.cos(np.arange(0,N_ramp)/N_ramp*np.pi))

    # Safety ceiling: the device's full-scale output voltage. A user-
    # requested ``amplitude`` bigger than this is clamped below so we
    # don't send a signal the hardware will reject or clip.
    limit = settings.output_vmax()

    # Create sig. Note 'sig' is choice of signal, while 'signal' is scipy.signal
    if sig == 'gaussian':
        y[:,selected_channels] = np.random.randn(N_per_channel,np.size(selected_channels))
        y[:,selected_channels] = stats.truncnorm.rvs(-limit/amplitude, limit/amplitude, loc=0,scale=amplitude, size=(N_per_channel,np.size(selected_channels)))
        if f is not None:
            b,a = signal.butter(3,f,btype='bandpass',fs=settings.output_fs)
            y = signal.filtfilt(b,a,y,axis=0,padtype=None)
            y = amplitude * y / np.sqrt(np.mean(y**2))
            if np.max(np.abs(y)) > limit:
                y = limit * y / np.max(np.abs(y))
                MESSAGE = 'Actual rms output after scaling to avoid clipping is {0:1.3f}'.format(np.sqrt(np.mean(y**2)))
            else:
                MESSAGE = 'Actual rms output is {0:1.3f}'.format(np.sqrt(np.mean(y**2)))
                
            
#            N_exceed_lim = np.sum(y>limit)+np.sum(y<-limit)
#            fraction_clipped = N_exceed_lim/np.size(y)
#            y[y>limit] = limit
#            y[y<-limit] = -limit
#            if fraction_clipped > 0:
#                print('{} out of {} samples exceeded output voltage limit of device and have been clipped'.format(N_exceed_lim,np.size(y)))
#            if fraction_clipped > 0.01:
#                print('{0:1.1f} percent of samples exceed output voltage limit of device'.format(fraction_clipped*100))
                
    elif sig == 'uniform':
        y[:,selected_channels] = np.random.uniform(low=-amplitude,high=amplitude,size=(N_per_channel,np.size(selected_channels)))
        if f is not None:
            b,a = signal.butter(3,f,btype='bandpass',fs=settings.output_fs)
            y = signal.filtfilt(b,a,y,axis=0,padtype=None)
            y = amplitude * y / np.sqrt(np.mean(y**2))
    elif sig == 'sweep':
        if f is None:
            f = [0,settings.output_fs/2]
        
        for ch in selected_channels:
            y[:,ch] = amplitude*signal.chirp(t,f[0],T,f[1])
    else:
        print('signal type must be one of {''gaussian'',''uniform'',''sweep''}')
        y = np.zeros((N_per_channel,settings.output_channels))
    
    y = win * y
    
    # Final safety clamp to ±limit (= output full-scale in volts).
    if np.max(np.abs(y)) > limit:
        y = limit * y / np.max(np.abs(y))
        MESSAGE = 'Actual rms output after scaling to avoid clipping is {0:1.3f}'.format(np.sqrt(np.mean(y**2)))

    return t,y


def stream_snapshot(rec):
    '''Capture the live oscilloscope buffer as a `TimeData`.

    Unlike `log_data`, which blocks for `stored_time` seconds and
    returns a fresh capture, this is a non-blocking snapshot of the
    oscilloscope-side circular buffer (`osc_time_data`) — i.e. the
    most recent `num_chunks * chunk_size` samples already in memory.
    Useful for "what is the stream doing right now?" diagnostics from
    a notebook while a stream is running.

    Parameters
    ----------
    rec : Recorder-like
        Retained for backward compatibility; the actual snapshot is
        always taken from the module-level `streams.REC`. Callers can
        pass any value (typically `streams.REC` itself).

    Returns
    -------
    TimeData
        A single `TimeData` instance with `test_name='stream_snapshot'`,
        carrying the oscilloscope axis and the live buffer. No
        `channel_cal_factors` or `units` are attached (this is meant
        as a quick-look tool, not a calibrated capture).

    Notes
    -----
    Requires a live stream: call `streams.start_stream(settings)`
    first, or use a function like `log_data` that does so internally.
    On the soundcard path the buffer holds voltages scaled by
    `settings.VmaxSC`; on the NI path it holds raw volts.
    '''
    time_data_copy = np.copy(streams.REC.osc_time_data)
    time_axis_copy = np.copy(streams.REC.osc_time_axis)
    
    t = datetime.datetime.now()
    timestring = '_'+str(t.year)+'_'+str(t.month)+'_'+str(t.day)+'_at_'+str(t.hour)+'_'+str(t.minute)+'_'+str(t.second)    

    time_data = datastructure.TimeData(time_axis_copy,time_data_copy,streams.REC.settings,timestamp=t,timestring=timestring,test_name='stream_snapshot')
    
    
    return time_data
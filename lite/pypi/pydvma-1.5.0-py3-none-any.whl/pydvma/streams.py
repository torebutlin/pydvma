from . import acquisition
from . import _ni_backend

import numpy as np
import pprint as pp
import time

try:
    import sounddevice as sd
except (ImportError, NotImplementedError, OSError):
    # OSError = package present but the PortAudio C library is
    # missing (default on ubuntu CI runners and some student
    # machines); treat it the same as sounddevice being absent.
    sd = None


try:
    import nidaqmx as ni
    from nidaqmx.stream_readers import AnalogMultiChannelReader
except ImportError:
    ni = None
    AnalogMultiChannelReader = None
except NotImplementedError:
    ni = None
    AnalogMultiChannelReader = None


#%% Handles the different cases of starting soundcard/NI streams


REC_SC = None # create global variable for creating only a single NI stream instance. Not needed for pyaudio.
REC_NI = None
REC_MOCK = None  # hardware-free test backend; see MockRecorder
REC = None


def _ni_recorder_class(settings):
    if ni is None:
        raise RuntimeError('nidaqmx is not installed; pip install nidaqmx')
    return Recorder_NI_nidaqmx


# IEPE warmup time in seconds. When excitation is freshly applied
# at task.start(), the sensor's DC bias rises through the AC-coupling
# HPF on the 9234 (~0.32 s RC time constant), creating a settling
# transient that decays exponentially. 2 s is ~6 RC time constants,
# i.e. settled to <0.3 % of the original bias step. Applied
# unconditionally inside `_build_and_start_ai_task` whenever any
# channel has IEPE enabled — keeps the data clean by default
# without exposing yet another setting. The `start_stream` reuse
# path (below) keeps an already-warmed task alive across log_data
# calls, so this 2 s cost is paid only on a genuine hardware-config
# change (different device, channels, fs, IEPE current, ...).
_IEPE_WARMUP_S = 2.0


def _ni_settings_signature(s):
    """Tuple of hardware-impacting AI-task settings.

    If the new settings' signature matches the running stream's, we
    can reuse the existing AI task and preserve its IEPE settling
    state. If anything in this tuple differs, the task must be torn
    down and rebuilt.

    Deliberately absent: ``pretrig_*`` and ``channel_sensitivities``,
    which only affect log_data's read-side processing — they don't
    re-program the hardware. ``output_*`` is also absent: those go to
    the separate AO task built by `setup_output_NI`, not the AI
    task this signature governs.
    """
    return (
        s.device_driver,
        s.device_index,
        int(s.channels),
        s.input_channels_spec,
        int(s.fs),
        int(s.chunk_size),
        int(s.num_chunks),
        s.NI_mode,
        float(s.VmaxNI),
        float(s.stored_time),  # affects stored_time_data buffer size
        tuple(np.asarray(s.iepe_excit_current_A).tolist()),
    )


def _clamp_soundcard_input_channels(settings):
    '''Clamp ``settings.channels`` to the soundcard input device's
    ``max_input_channels``, mutating ``settings`` in place.

    Why this exists: ``sd.InputStream(channels=N)`` raises PortAudio
    error ``-9998`` (paInvalidChannelCount) when ``N`` exceeds the
    device's reported capability. The default ``MySettings()`` asks
    for ``channels=2``, but a Mac built-in microphone is typically
    mono — so the default path failed cryptically on Mac before this
    clamp. The NI backend already validates analogously (raises
    ``ValueError``) — see `Recorder_NI_nidaqmx.__init__`. Soundcard
    clamps rather than raises because the GUI's
    ``setup_frame_tools_settings`` silently auto-builds default
    settings when the user passes none, so raising would surface an
    error against a value the user never picked.

    Called from `start_stream` *before* `Recorder(settings)` is
    constructed, so the clamped value flows into both buffer
    allocation (`Recorder.__init__`) and the actual
    `sd.InputStream` opening (`Recorder.init_stream`). A no-op when
    ``sd`` is unavailable, when the device default can't be resolved,
    or when ``settings.channels`` already fits.
    '''
    if sd is None:
        return
    if settings.device_index is None:
        try:
            settings.device_index = sd.default.device[0]
        except (AttributeError, TypeError, IndexError):
            return
    try:
        in_info = sd.query_devices(settings.device_index)
    except (sd.PortAudioError, ValueError, TypeError):
        return
    max_in = int(in_info['max_input_channels'])
    if settings.channels > max_in:
        print("WARNING: input device %r supports only %d input channel(s); "
              "requested channels=%d. Clamping to %d."
              % (in_info['name'], max_in, settings.channels, max_in))
        settings.channels = max_in


def _clamp_soundcard_output_channels(settings):
    '''Clamp ``settings.output_channels`` to the soundcard output
    device's ``max_output_channels``, mutating ``settings`` in place.

    Mirror of `_clamp_soundcard_input_channels` for the output path.
    Called from `setup_output_soundcard` because output streams are
    opened on a separate code path from input (`acquisition.output_signal`
    → `setup_output_soundcard`), not via `start_stream`. A no-op when
    ``sd`` is unavailable, the output device can't be resolved, or
    ``settings.output_channels`` already fits.
    '''
    if sd is None:
        return
    if settings.output_device_index is None:
        try:
            settings.output_device_index = sd.default.device[1]
        except (AttributeError, TypeError, IndexError):
            return
    try:
        out_info = sd.query_devices(settings.output_device_index)
    except (sd.PortAudioError, ValueError, TypeError):
        return
    max_out = int(out_info['max_output_channels'])
    if settings.output_channels > max_out:
        print("WARNING: output device %r supports only %d output channel(s); "
              "requested output_channels=%d. Clamping to %d."
              % (out_info['name'], max_out, settings.output_channels, max_out))
        settings.output_channels = max_out


def start_stream(settings):
    global REC_SC, REC_NI, REC, REC_MOCK
    if settings.device_driver == 'mock':
        # Hardware-free test backend — no real audio / NI device opened.
        # Used by tests/test_acquisition_mock.py to exercise the
        # log_data / output_signal / stream_snapshot paths on machines
        # without a soundcard or NI-DAQmx driver. See `MockRecorder`.
        REC_MOCK = MockRecorder(settings)
        REC_MOCK.init_stream(settings)
        REC = REC_MOCK
    elif settings.device_driver == 'soundcard':
        # Clamp channels to the device's max_input_channels before
        # constructing the Recorder — buffer shapes in
        # `Recorder.__init__` use `settings.channels`, so any clamping
        # has to happen here, not inside `init_stream`.
        _clamp_soundcard_input_channels(settings)
        REC_SC = Recorder(settings)
        REC_SC.init_stream(settings)
        REC = REC_SC
    elif settings.device_driver == 'nidaq':
        cls = _ni_recorder_class(settings)
        # Reuse path: an existing recorder has a live AI task whose
        # hardware configuration matches the requested settings. Keep
        # the task running — preserves IEPE excitation settling — and
        # just refresh the trigger state for the next capture. Any
        # log_data-side fields (pretrig_*, channel_sensitivities,
        # output_*) get picked up via the settings reference update
        # and applied at read time.
        if (REC_NI is not None
                and isinstance(REC_NI, cls)
                and REC_NI.audio_stream is not None
                and _ni_settings_signature(REC_NI.settings)
                    == _ni_settings_signature(settings)):
            REC_NI.settings = settings
            REC_NI.trigger_detected = False
            REC_NI.trigger_first_detected_message = False
            REC = REC_NI
            return

        # Rebuild path: hardware config changed (different device,
        # channels, fs, IEPE current, ...) or there's no live task.
        # If an existing REC_NI was created by a different backend, drop it.
        if REC_NI is not None and not isinstance(REC_NI, cls):
            try:
                REC_NI.end_stream()
            except Exception:
                pass
            REC_NI = None
        if REC_NI is None:
            REC_NI = cls(settings)
        else:
            try:
                REC_NI.end_stream()
            except Exception:
                pass
        REC_NI.__init__(settings)
        REC_NI.init_stream(settings)
        REC = REC_NI
        print(REC)
    else:
        raise ValueError('Unknown driver: %r' % settings.device_driver)
        
#%% Find information on available devices
def list_available_devices(io=''):
    # soundcard devices list
    message = '__________________________________________________________\n'
    message += '\n'
    message += 'Devices available using device_driver=''soundcard'', by index:\n'
    message += '__________________________________________________________\n'
    message += '\n'

    device_name_list = get_devices_soundcard()
    if device_name_list is not None:
        N = np.size(device_name_list)
        for i in range(N):
            if io.lower() in device_name_list[i].lower(): # option to only look for input devices
                message += '{}: {}\n'.format(i,device_name_list[i])
    
        try:
            default_input_device = sd.default.device[0]
            message += '\nDefault device is: [%i] %s\n' %(default_input_device,device_name_list[default_input_device])
            message += '\n'
            default_output_device = sd.default.device[1]
            message += 'Default device is: [%i] %s\n' %(default_output_device,device_name_list[default_output_device])
            message += '\n\n'
        except (AttributeError, TypeError, IndexError):
            # sd.default is None (no PortAudio host), or
            # sd.default.device is -1 / not indexable on a headless
            # machine — fall back to "unknown" without pretending any
            # specific device is the default.
            message += 'default information not available\n'
    else:
        message += 'no soundcards found\n'
    
    # NI list (nidaqmx view — cDAQ chassis collapsed into a single entry)
    message += '______________________________________________________\n'
    message += '\n'
    message += "Devices available using device_driver='nidaq', by index:\n"
    message += '______________________________________________________\n'
    message += '\n'
    if ni is None:
        message += 'nidaqmx is not installed\n'
    else:
        entries = _ni_backend.enumerate_devices()
        if not entries:
            message += 'no NI devices found via nidaqmx\n'
        else:
            for i, e in enumerate(entries):
                tag = 'chassis' if e['is_chassis'] else 'device'
                message += '{}: {} ({}, {}) AI={} AO={}'.format(
                    i, e['name'], e['product_type'], tag,
                    e['ai_channel_count'], e['ao_channel_count'],
                )
                if e['is_chassis']:
                    message += ' modules={}'.format(e['module_names'])
                message += '\n'

    print(message)
    return message
    
    
        

def get_devices_NI():
    '''Return (names, types) of every NI device/module visible to nidaqmx.

    Flat list — a cDAQ chassis appears alongside each of its slotted
    modules (e.g. ``['cDAQ1', 'cDAQ1Mod1', 'cDAQ1Mod2']``). For the
    chassis-collapsed view used by `Recorder_NI_nidaqmx` itself, call
    `_ni_backend.enumerate_devices` directly.

    Returns ``(None, None)`` if nidaqmx is not installed or no devices
    are visible, keeping the pre-nidaqmx API shape.
    '''
    if ni is None:
        return None, None
    try:
        system = ni.system.System.local()
        names = [d.name for d in system.devices]
        types = [d.product_type for d in system.devices]
    except Exception:
        return None, None
    if not names:
        return None, None
    return names, types


def get_devices_soundcard():
    if sd is None:
        return None
    try:
        devices = sd.query_devices()
        device_name_list = []
        for device in devices:
            device_name_list.append(device['name'])
    except (sd.PortAudioError, AttributeError, TypeError):
        # PortAudio subsystem not available, or sd.query_devices()
        # returned something without the expected dict-of-device shape
        # (unusual driver config). Treat as "no devices visible".
        return None
    
    return device_name_list

# def get_devices_soundcard():
#     try:
#         audio = pyaudio.PyAudio()
#         device_count = audio.get_device_count()
#         device_name_list = []
#         for i in range(device_count):
#             device = audio.get_device_info_by_index(i)
#             device_name_list.append(device['name'])
#     except:
#         return None
    
#     return device_name_list


#%% sounddevice stream
class Recorder(object):
    '''Soundcard acquisition recorder (via `sounddevice`).

    Owns two circular buffers:

    * ``osc_time_data`` — shape ``(num_chunks * chunk_size, channels)``
      — always live; fed the most-recent samples for the oscilloscope.
    * ``stored_time_data`` — shape ``(stored_num_chunks * chunk_size,
      channels)`` where ``stored_num_chunks = 2 + ceil(stored_time * fs
      / chunk_size)`` — the capture buffer used by `log_data`.

    Trigger / pretrigger state machine
    ----------------------------------
    Each incoming chunk (``chunk_size`` samples, ``channels`` wide)
    runs through `callback`:

    1. Shift both buffers left by ``chunk_size`` and append the new
       chunk at the end. When ``pretrig_samples is not None`` and
       ``trigger_detected`` is already True, `stored_time_data` is
       **frozen** — only `osc_time_data` keeps scrolling.
    2. "First-detect" message: if any sample in the just-read chunk
       exceeds ``pretrig_threshold`` on the monitored
       ``pretrig_channel``, print a one-shot notice. Independent of
       whether the trigger has actually been committed yet.
    3. Trigger check: look at ``stored_time_data[chunk_size :
       2*chunk_size, pretrig_channel]`` (the *second-oldest* chunk in
       the buffer — see below). If any sample exceeds
       ``pretrig_threshold``, set ``trigger_detected = True`` and
       freeze the buffer on subsequent callbacks.

    The "check the second-oldest chunk" design means that by the
    time a trigger is detected, the buffer already holds ~``stored_time
    * fs`` samples of *post*-trigger data and up to ``chunk_size``
    samples of *pre*-trigger data. `log_data` uses this to return a
    window straddling the trigger with ``pretrig_samples`` samples of
    context before it — see `pydvma.acquisition.log_data`. The
    ``chunk_size`` ceiling on the pre-trigger context is why
    ``pretrig_samples > chunk_size`` is rejected.

    Data convention
    ---------------
    Both buffers store voltages. sounddevice delivers float32 samples
    in ±1 normalised units; the callback scales by
    ``settings.VmaxSC`` on the way in, so consumers see a calibrated
    reading at the input jack (``VmaxSC`` = the voltage corresponding
    to a normalised 1.0). Default ``VmaxSC=1.0`` means no calibration
    — ±1 normalised is returned as ±1 "V" — which keeps behaviour
    byte-identical to the old convention for anyone who hasn't
    measured their soundcard's sensitivity.

    Channel-count clamping
    ----------------------
    The buffer shapes are derived from ``settings.channels`` at
    construction time. To keep these consistent with what the
    PortAudio device will actually accept, `start_stream` calls
    `_clamp_soundcard_input_channels` *before* constructing this
    Recorder — so by the time ``__init__`` runs, ``settings.channels``
    is already clamped to ``max_input_channels`` (with a printed
    warning when clamping happened). This avoids the cryptic
    ``PortAudioError -9998`` on devices like a Mac built-in mono mic
    when defaults asked for 2 channels.
    '''
    def __init__(self,settings):
        self.settings = settings
        self.trigger_detected = False
        self.trigger_first_detected_message = False
        self.osc_time_axis=np.arange(0,(self.settings.num_chunks*self.settings.chunk_size)/self.settings.fs,1/self.settings.fs)
        self.osc_freq_axis=np.fft.rfftfreq(len(self.osc_time_axis),1/self.settings.fs)
        self.osc_time_data=np.zeros(shape=((self.settings.num_chunks*self.settings.chunk_size),self.settings.channels))  
        self.osc_time_data_windowed=np.zeros_like(self.osc_time_data)
        self.osc_freq_data = np.abs(np.fft.rfft(self.osc_time_data,axis=0))

        
        #rounds up the number of chunks needed in the pretrig array    
        self.stored_num_chunks=2+int(np.ceil((self.settings.stored_time*self.settings.fs)/self.settings.chunk_size))
        #the +2 is to allow for the updating process on either side
        self.stored_time_data=np.zeros(shape=(self.stored_num_chunks*self.settings.chunk_size,self.settings.channels))
        self.stored_time_data_windowed=np.zeros_like(self.stored_time_data)
        #note the +2s to match up the length of stored_num_chunks
        #formula used from the np.fft.rfft documentation
        self.stored_freq_data = np.abs(np.fft.rfft(self.stored_time_data,axis=0))
        # self.list_dt = []
    
    def callback(self, in_data, frame_count, time_info, status):
        '''
        Obtains data from the audio stream.

        The sounddevice callback delivers float32 samples in ±1
        normalised units; we scale by ``settings.VmaxSC`` on the way
        in so both `osc_time_data` and `stored_time_data` are in
        volts (where "volts" means "ŷ × VmaxSC", with ŷ the
        normalised sample). VmaxSC defaults to 1.0 so uncalibrated
        soundcards keep identical numeric behaviour to the old ±1
        convention.
        '''
        t0 = time.time()
        # self.osc_data_chunk = (np.frombuffer(in_data, dtype='int'+str(self.settings.nbits))/2**(self.settings.nbits-1))
        self.osc_data_chunk = np.copy(in_data) * self.settings.VmaxSC
        self.osc_data_chunk=np.reshape(self.osc_data_chunk,[self.settings.chunk_size,self.settings.channels])
        for i in range(self.settings.channels):
            self.osc_time_data[:-(self.settings.chunk_size),i] = self.osc_time_data[self.settings.chunk_size:,i]
            self.osc_time_data[-(self.settings.chunk_size):,i] = self.osc_data_chunk[:,i]
            if (not self.trigger_detected)  or (self.settings.pretrig_samples is None):
                self.stored_time_data[:-(self.settings.chunk_size),i] = self.stored_time_data[self.settings.chunk_size:,i]
                self.stored_time_data[-(self.settings.chunk_size):,i] = self.osc_data_chunk[:,i]
        
        trigger_first_detected = np.any(np.abs(self.osc_data_chunk[:,self.settings.pretrig_channel])>self.settings.pretrig_threshold)
        if trigger_first_detected and self.trigger_first_detected_message:
            acquisition.MESSAGE += 'Trigger detected. Logging data for {} seconds.\n'.format(self.settings.stored_time)
            print('')
            print(acquisition.MESSAGE)
            self.trigger_first_detected_message=False
            
            
        trigger_check = self.stored_time_data[(self.settings.chunk_size):(2*self.settings.chunk_size),self.settings.pretrig_channel]
        if np.any(np.abs(trigger_check)>self.settings.pretrig_threshold):
            # freeze updating stored_time_data
            self.trigger_detected = True

        # self.list_dt += [time.time()-t0]

        # return in_data
    
    
    def init_stream(self,settings,_input_=True,_output_=False):
        '''Open the live `sd.InputStream` against ``settings.device_index``.

        If ``settings.device_index`` is ``None`` it's resolved to
        ``sd.default.device[0]`` and printed to stdout. ``settings.channels``
        is assumed to already fit the device — `start_stream` clamps it
        via `_clamp_soundcard_input_channels` before this method runs,
        so the value passed to ``sd.InputStream`` will not exceed the
        device's ``max_input_channels`` even if the caller asked for more.
        '''
        
        if settings.device_index is None:
    
            devices = sd.query_devices()
            print('No device specified. Using default:\n\n%i %s'
                  %(sd.default.device[0],devices[sd.default.device[0]]['name']))
            print ('')
            settings.device_index=sd.default.device[0]
            
        settings.device_name = sd.query_devices()[settings.device_index]['name']
        settings.device_full_info = sd.query_devices()[settings.device_index]
        
        dtype = 'float32'
        self.audio_stream = sd.InputStream(samplerate=settings.fs, 
                                      blocksize=settings.chunk_size, 
                                      device=settings.device_index, 
                                      channels=settings.channels, 
                                      dtype=dtype, 
                                      latency='low', 
                                      extra_settings=None, 
                                      callback=self.callback, 
                                      finished_callback=None, 
                                      clip_off=None, 
                                      dither_off=None, 
                                      never_drop_input=None, 
                                      prime_output_buffers_using_stream_callback=None) 
        self.audio_stream.start()
        
        
    
    def end_stream(self):
        '''
        Stops and closes the audio stream, tolerating a stream that was
        never opened or is already dead (e.g. after a device
        disconnect) — matching the NI recorder's behaviour. Clears the
        module-level ``REC`` reference.
        '''
        global REC
        REC = None
        stream = getattr(self, 'audio_stream', None)
        if stream is None:
            return
        try:
            if stream.active:
                stream.stop()
        except Exception:
            pass
        try:
            stream.close()
        except Exception:
            pass
        self.audio_stream = None

        
        



#%% NI stream (nidaqmx backend)


def _ni_callback_interval(chunk_size):
    '''Cadence (in samples) for the NI every-N-samples acquisition
    callback.

    Must equal the per-callback read size (``settings.chunk_size``):
    each callback reads exactly one chunk, so a shorter interval makes
    events fire faster than reads consume samples (unbounded event
    backlog, blocking reads) and a longer one would starve the reads.

    Args:
        chunk_size (int): samples read per callback; must be >= 1.

    Returns:
        int: the validated callback interval (== chunk_size).
    '''
    n = int(chunk_size)
    if n < 1:
        raise ValueError(
            'chunk_size must be >= 1 for the NI callback interval, '
            'got {!r}'.format(chunk_size)
        )
    return n


class Recorder_NI_nidaqmx(object):
    '''NI acquisition recorder using the official nidaqmx Python wrapper.

    Exposes the same public attribute shape the soundcard `Recorder`
    does — `audio_stream`, `osc_time_data`, `stored_time_data`,
    `trigger_detected`, etc. — so `acquisition.py` is driver-agnostic.

    Trigger / pretrigger state machine
    ----------------------------------
    Identical to `Recorder` — see that class's docstring for the full
    description. The only differences in this path are (a) the data
    source (the nidaqmx every-N-samples callback calling
    `read_many_sample` rather than a sounddevice input-stream callback)
    and (b) the sample units: **raw volts** from
    `AnalogMultiChannelReader`, not ±1-normalised float. Thresholds
    (`pretrig_threshold`) are applied with identical code but mean
    different things in the two paths — always specify thresholds in
    the units your chosen device delivers.

    Hardware-specific notes picked up while getting this working:

    * **cDAQ chassis** are addressed via a single entry in the
      enumerated device list. A chassis with an N-channel AI module and
      an M-channel AO module appears as one device with
      ``ai_channel_count=N`` and ``ao_channel_count=M``. Requesting
      ``channels=N`` builds the correct cross-module channel string
      (``cDAQ1Mod1/ai0:N-1``). For mixed / gappy layouts, use the
      ``input_channels_spec`` / ``output_channels_spec`` settings to
      pass a raw physical-channel string.
    * **NI 9234** (and DSA modules generally) are pseudo-differential
      only; set ``NI_mode='DAQmx_Val_PseudoDiff'``. Voltage range is
      fixed at ±5 V; any other ``VmaxNI`` will be accepted silently
      by the driver.
    * **NI 9260** AO is ±4.24 V peak (= 3 V_rms). Setting
      ``output_VmaxNI=10`` triggers DAQmx error -200077.
    * **USB-600x low-cost devices** have software-timed AO: AI/AO
      cannot share a hardware sample clock; the output path falls back
      to an independent (unsynchronised) task.
    * **Data is read in volts** directly via `AnalogMultiChannelReader`,
      not as a normalised float — no ±1 scaling is applied. This
      differs from the soundcard path, which returns ±1-normalised
      float32.
    '''

    def __init__(self, settings):
        self.settings = settings
        self.trigger_detected = False
        self.trigger_first_detected_message = False

        self.osc_time_axis = np.arange(
            0,
            (settings.num_chunks * settings.chunk_size) / settings.fs,
            1 / settings.fs,
        )
        self.osc_freq_axis = np.fft.rfftfreq(len(self.osc_time_axis), 1 / settings.fs)
        self.osc_time_data = np.zeros(
            shape=(settings.num_chunks * settings.chunk_size, settings.channels)
        )
        self.osc_time_data_windowed = np.zeros_like(self.osc_time_data)
        self.osc_freq_data = np.abs(np.fft.rfft(self.osc_time_data, axis=0))

        self.stored_num_chunks = 2 + int(
            np.ceil((settings.stored_time * settings.fs) / settings.chunk_size)
        )
        self.stored_time_data = np.zeros(
            shape=(self.stored_num_chunks * settings.chunk_size, settings.channels)
        )
        self.stored_time_data_windowed = np.zeros_like(self.stored_time_data)
        self.stored_freq_data = np.abs(np.fft.rfft(self.stored_time_data, axis=0))

        entries = _ni_backend.enumerate_devices()
        if not entries:
            raise RuntimeError('No NI devices found via nidaqmx')
        idx = settings.device_index if settings.device_index is not None else 0
        if idx >= len(entries):
            raise ValueError(
                'device_index %r out of range; nidaqmx sees %d device(s)'
                % (settings.device_index, len(entries))
            )
        self.device_entry = entries[idx]
        self.device_name = self.device_entry['name']

        if settings.channels > self.device_entry['ai_channel_count'] and not settings.input_channels_spec:
            raise ValueError(
                'Requested %d AI channels but %r has only %d available'
                % (settings.channels, self.device_name, self.device_entry['ai_channel_count'])
            )

        # Preserve hardware-level state across re-__init__ calls:
        # acquisition.py re-invokes __init__ to zero the numpy buffers
        # before a pretrigger wait, but the NI task is still running and
        # its callback expects the reader to still exist. Only set these
        # on first construction.
        if not hasattr(self, 'audio_stream'):
            self.audio_stream = None
            self._reader = None
            self._read_buffer = None
            self._callback_ref = None  # keep a strong reference for nidaqmx

    def available_devices(self):
        entries = _ni_backend.enumerate_devices()
        return ([e['name'] for e in entries], [e['product_type'] for e in entries])

    def current_device_info(self):
        pp.pprint(self.device_entry)

    def set_channels(self):
        return _ni_backend.build_ai_channel_string(
            self.device_entry,
            self.settings.channels,
            self.settings.input_channels_spec,
        )

    def set_output_channels(self):
        return _ni_backend.build_ao_channel_string(
            self.device_entry,
            self.settings.output_channels,
            self.settings.output_channels_spec,
        )

    def stream_audio_callback(self):
        try:
            self._reader.read_many_sample(
                self._read_buffer,
                number_of_samples_per_channel=self.settings.chunk_size,
                timeout=10.0,
            )
        except Exception as e:
            print('nidaqmx read error:', e)
            return 0

        # Reader fills shape (channels, chunk_size); downstream wants
        # (chunk_size, channels) to match the soundcard path.
        data_array = self._read_buffer.T
        self.osc_data_chunk = data_array

        for i in range(self.settings.channels):
            self.osc_time_data[:-(self.settings.chunk_size), i] = self.osc_time_data[self.settings.chunk_size:, i]
            self.osc_time_data[-(self.settings.chunk_size):, i] = self.osc_data_chunk[:, i]
            if (not self.trigger_detected) or (self.settings.pretrig_samples is None):
                self.stored_time_data[:-(self.settings.chunk_size), i] = self.stored_time_data[self.settings.chunk_size:, i]
                self.stored_time_data[-(self.settings.chunk_size):, i] = self.osc_data_chunk[:, i]

        trigger_first_detected = np.any(
            np.abs(self.osc_data_chunk[:, self.settings.pretrig_channel])
            > self.settings.pretrig_threshold
        )
        if trigger_first_detected and self.trigger_first_detected_message:
            acquisition.MESSAGE += 'Trigger detected. Logging data for {} seconds.\n'.format(
                self.settings.stored_time
            )
            print('')
            print(acquisition.MESSAGE)
            self.trigger_first_detected_message = False

        trigger_check = self.stored_time_data[
            self.settings.chunk_size:(2 * self.settings.chunk_size),
            self.settings.pretrig_channel,
        ]
        if np.any(np.abs(trigger_check) > self.settings.pretrig_threshold):
            self.trigger_detected = True
        return 0

    def init_stream(self, settings, _input_=True, _output_=False):
        # Tear down any previous task on this recorder
        if self.audio_stream is not None:
            try:
                self.audio_stream.stop()
            except Exception:
                pass
            try:
                self.audio_stream.close()
            except Exception:
                pass
            self.audio_stream = None

        try:
            self._build_and_start_ai_task(settings)
        except ni.errors.DaqError as e:
            # -50103 "The specified resource is reserved" usually means a
            # prior Python process leaked the task (notebook kernel crash,
            # Ctrl-C, etc.) and Windows is still holding the reservation.
            # Reset the device once to clear it and retry; surface any
            # other DAQmx error unchanged.
            if e.error_code != -50103:
                raise
            if self.audio_stream is not None:
                try:
                    self.audio_stream.close()
                except Exception:
                    pass
                self.audio_stream = None
            try:
                ni.system.Device(self.device_name).reset_device()
            except Exception:
                pass
            self._build_and_start_ai_task(settings)

    def _build_and_start_ai_task(self, settings):
        # Callback cadence must equal the per-callback read size —
        # see _ni_callback_interval.
        AutoRegN = _ni_callback_interval(settings.chunk_size)

        term_config = _ni_backend.resolve_terminal_config(settings.NI_mode)
        task = ni.Task()
        task.ai_channels.add_ai_voltage_chan(
            self.set_channels(),
            terminal_config=term_config,
            min_val=-float(settings.VmaxNI),
            max_val=+float(settings.VmaxNI),
        )
        task.timing.cfg_samp_clk_timing(
            rate=float(settings.fs),
            sample_mode=ni.constants.AcquisitionType.CONTINUOUS,
            samps_per_chan=int(settings.chunk_size),
        )

        # Per-channel IEPE / ICP excitation. Setting any channel's
        # excitation requires the sample clock to be configured first
        # (DSA modules reject the property otherwise — DAQmx -201087).
        self._apply_per_channel_iepe(task, settings)

        self._read_buffer = np.zeros(
            (settings.channels, settings.chunk_size), dtype=np.float64
        )
        self._reader = AnalogMultiChannelReader(task.in_stream)

        def _cb(task_handle, event_type, number_of_samples, callback_data):
            try:
                return self.stream_audio_callback()
            except Exception as e:
                print('stream_audio_callback error:', e)
                return 0

        self._callback_ref = _cb
        task.register_every_n_samples_acquired_into_buffer_event(AutoRegN, _cb)

        # Assign before start so the retry path in ``init_stream`` can
        # find the task to close if ``task.start()`` raises -50103.
        self.audio_stream = task
        task.start()

        # IEPE warmup: when the 2 mA excitation step turns on at
        # task.start(), the sensor's DC bias rises and propagates
        # through the 9234's AC-coupling HPF. Block until that step
        # has decayed below the noise floor before letting callers
        # read the buffer; otherwise the first capture is dominated
        # by the bias transient (mean drifting from ~12 V to 0).
        if np.any(np.asarray(settings.iepe_excit_current_A) > 0):
            print('IEPE excitation settling for {} s...'.format(_IEPE_WARMUP_S))
            time.sleep(_IEPE_WARMUP_S)

    def _apply_per_channel_iepe(self, task, settings):
        """Apply IEPE excitation + AC coupling per channel from settings.

        ``settings.iepe_excit_current_A`` is an array of length
        ``channels`` (validated in ``MySettings.__init__``). Channels
        with ``> 0`` get internal current excitation at that value
        plus AC coupling (the standard for IEPE/ICP sensors); channels
        with ``0`` are left at the device's default (no excitation, DC
        coupling on the 9234).

        Validates against the *owning* module's advertised
        ``ai_current_int_excit_discrete_vals`` so requesting an
        unsupported current (e.g. 2 mA on a USB-6003) fails loudly
        rather than being silently ignored. On a multi-module chassis
        each channel is checked against the module that actually
        supplies it (channels can span modules — e.g. an IEPE accel on
        the second AI module while the first carries a loopback), so a
        legal current on one module is not assumed legal on another.
        """
        currents = np.asarray(settings.iepe_excit_current_A, dtype=float)
        if not np.any(currents > 0):
            return  # all channels off — nothing to do

        channels = list(task.ai_channels)
        if len(channels) != len(currents):
            raise RuntimeError(
                'IEPE configuration mismatch: task has {} channels but '
                'settings.iepe_excit_current_A has {} entries'
                .format(len(channels), len(currents))
            )

        # Map each channel index to the device (chassis module, or the
        # standalone device itself) that supplies it, so each requested
        # current is validated against the right hardware.
        owning = _ni_backend.ai_channel_module_map(
            self.device_entry, len(currents),
        )
        allowed_cache = {}

        def _allowed_for(dev_name):
            if dev_name not in allowed_cache:
                try:
                    vals = list(
                        ni.system.Device(dev_name)
                        .ai_current_int_excit_discrete_vals
                    )
                except (ni.errors.DaqError, AttributeError):
                    vals = []
                # 0.0 is always implicitly allowed (= no excitation).
                allowed_cache[dev_name] = {0.0} | {float(v) for v in vals}
            return allowed_cache[dev_name]

        for idx, current in enumerate(currents):
            if current <= 0:
                continue
            dev_name = owning[idx]
            allowed_set = _allowed_for(dev_name)
            if not any(abs(current - a) < 1e-9 for a in allowed_set):
                raise ValueError(
                    'iepe_excit_current_A={} A on channel {} is not '
                    'supported by {} (allowed: {} A). Set to 0.0 to '
                    'disable IEPE.'
                    .format(current, idx, dev_name, sorted(allowed_set))
                )
        for ch, current in zip(channels, currents):
            if current > 0:
                ch.ai_excit_src = ni.constants.ExcitationSource.INTERNAL
                ch.ai_excit_val = float(current)
                ch.ai_coupling = ni.constants.Coupling.AC

    def setup_output(self, settings, output):
        # Delegate to the module-level helper so both call paths share the
        # same (validated) implementation.
        return setup_output_NI_nidaqmx(settings, output)

    def end_stream(self):
        global REC
        REC = None
        if self.audio_stream is not None:
            try:
                self.audio_stream.stop()
            except Exception:
                pass
            try:
                self.audio_stream.close()
            except Exception:
                pass
            self.audio_stream = None
        self._reader = None
        self._read_buffer = None
        self._callback_ref = None


# Backwards-compatibility alias: the public API has always exposed
# `Recorder_NI`, and external notebooks/scripts may still import it
# by that name. Kept pointing at the (now sole) nidaqmx recorder.
Recorder_NI = Recorder_NI_nidaqmx


#%% NI output

def setup_output_NI(settings, output):
    '''Build and stage (but not start) an NI AO task.

    Thin wrapper that defers to `setup_output_NI_nidaqmx` — the
    nidaqmx backend is now the only NI path.
    '''
    if ni is None:
        raise RuntimeError('nidaqmx is not installed; pip install nidaqmx')
    return setup_output_NI_nidaqmx(settings, output)


class _NidaqmxTaskAdapter(object):
    '''Expose the PascalCase methods acquisition.py calls on the NI
    output stream (StartTask, StopTask, WaitUntilTaskDone). Any other
    attribute access falls through to the underlying nidaqmx.Task.
    '''
    def __init__(self, task):
        self._task = task

    def StartTask(self):
        self._task.start()

    def StopTask(self):
        try:
            self._task.stop()
        except Exception:
            pass
        try:
            self._task.close()
        except Exception:
            pass

    def WaitUntilTaskDone(self, timeout):
        self._task.wait_until_done(timeout=float(timeout))

    def ClearTask(self):
        try:
            self._task.close()
        except Exception:
            pass

    def __getattr__(self, name):
        return getattr(self._task, name)


def _ao_module_name(device_entry):
    """Return the name of the device's AO-providing module (the chassis
    slot for a cDAQ, or the device itself for a standalone USB/PCIe
    DAQ). Used by `_check_output_vmax_within_hardware` to look up the
    actual hardware AO range. Returns None if no AO module is found."""
    if device_entry['is_chassis']:
        for mod in device_entry['module_names']:
            if device_entry['module_ao_counts'].get(mod, 0) > 0:
                return mod
        return None
    return device_entry['name']


def _check_output_vmax_within_hardware(device_entry, requested_vmax):
    """Raise ValueError if ``requested_vmax`` exceeds the AO module's
    largest range, with a clear message that names the actual hardware
    limit and points the caller at `suggest_ni_settings` for safe
    defaults. Best-effort: if the device's `ao_voltage_ranges` can't be
    queried, silently fall through and let DAQmx surface the error
    itself (still a clear -200077 with min/max attached)."""
    from . import _ni_device_specs    # local import to avoid load-order cycles
    ao_mod = _ao_module_name(device_entry)
    if ao_mod is None:
        return
    try:
        info = _ni_device_specs.get_device_info(ao_mod)
    except (RuntimeError, ni.errors.DaqError):
        return
    ranges = info.get('ao_voltage_ranges') or []
    if not ranges:
        return
    hw_max = max(rmax for _, rmax in ranges)
    if requested_vmax > hw_max + 1e-9:
        raise ValueError(
            'output_VmaxNI = {:.4f} V exceeds the maximum output voltage '
            'of {} ({}) on this hardware ({:.4f} V). Lower output_VmaxNI '
            'in MySettings, or call dvma.suggest_ni_settings(device_index='
            '{!r}) to get safe defaults for this device.'.format(
                requested_vmax, ao_mod, info.get('product_type', '?'),
                hw_max, device_entry['name'],
            )
        )


def setup_output_NI_nidaqmx(settings, output):
    '''Build and stage (but not start) a finite-sample AO task on nidaqmx.

    Parameters
    ----------
    settings : MySettings
        Must have ``output_device_driver='nidaq'``. ``output`` is
        expected in **volts**; the AO task is configured with ranges
        ±``output_VmaxNI`` so any sample outside that range will be
        rejected by DAQmx (error -200077).
    output : ndarray, shape (N_samples, output_channels)
        Playback waveform, in volts. Must stay within ±``output_VmaxNI``
        (e.g. NI 9260 is ±4.24 V peak regardless of the requested
        range).

    Returns
    -------
    _NidaqmxTaskAdapter
        Wrapper exposing ``StartTask`` / ``StopTask`` /
        ``WaitUntilTaskDone`` so `acquisition.py` can call the same
        methods regardless of whether the source is an NI or soundcard
        stream.

    Notes on AI/AO hardware sync
    ----------------------------
    When the AI recorder is a `Recorder_NI_nidaqmx` on the **same
    device or chassis** and that hardware supports hardware-timed AO
    (see `_ni_backend.supports_hw_ao_sync`), the AO task routes the
    AI sample clock as its source — the resulting AO samples step on
    exactly the AI tick. This works on M/X-series USB (e.g.
    USB-6212). It is **not** used for cDAQ chassis: per-module AI
    sample clocks are not routable as AO sources there; AI and AO
    instead share the chassis 80 MHz timebase implicitly, which is
    phase-coherent but not sample-accurate across tasks. USB-600x
    low-cost devices have software-timed AO and always run
    unsynchronised.
    '''
    # `output` is already in volts; no pre-scaling needed.
    output = np.asarray(output)
    output_shape = np.shape(output)
    N_output = output_shape[0]
    N_channel_check = output_shape[1]
    if N_channel_check != settings.output_channels:
        print("output matrix doesn't match number of output channels")

    entries = _ni_backend.enumerate_devices()
    if not entries:
        raise RuntimeError('No NI devices found via nidaqmx')
    if settings.output_device_index is None or settings.output_device_index >= len(entries):
        raise ValueError(
            'output_device_index %r out of range; nidaqmx sees %d device(s)'
            % (settings.output_device_index, len(entries))
        )
    device_entry = entries[settings.output_device_index]
    channel_string = _ni_backend.build_ao_channel_string(
        device_entry, settings.output_channels, settings.output_channels_spec,
    )

    # Pre-check output_VmaxNI against the AO module's actual capability.
    # DAQmx will reject e.g. +/-5 V on the NI 9260 (max +/-4.242641 V) with
    # an opaque -200077 at channel creation; raising a clearer error here
    # with the device's real limit + a pointer to suggest_ni_settings is
    # much friendlier, especially when the call comes from the GUI's
    # default-settings path.
    _check_output_vmax_within_hardware(device_entry, settings.output_VmaxNI)

    task = ni.Task()
    task.ao_channels.add_ao_voltage_chan(
        channel_string,
        min_val=-float(settings.output_VmaxNI),
        max_val=+float(settings.output_VmaxNI),
    )

    # Share the AI sample clock when possible: both input and output are NI,
    # the AI recorder is on the same device/chassis, and hardware-timed AO
    # is supported. Falls back to the device's own timebase otherwise.
    clock_source = ''
    if (settings.device_driver == 'nidaq'
            and _ni_backend.supports_hw_ao_sync(device_entry)
            and isinstance(REC_NI, Recorder_NI_nidaqmx)
            and REC_NI.device_entry is not None
            and REC_NI.device_entry['name'] == device_entry['name']):
        clock_source = _ni_backend.ai_sample_clock_source(device_entry) or ''

    task.timing.cfg_samp_clk_timing(
        rate=float(settings.output_fs),
        source=clock_source,
        sample_mode=ni.constants.AcquisitionType.FINITE,
        samps_per_chan=int(N_output),
    )

    # nidaqmx write: shape is (n_channels, n_samples) for multi-channel,
    # or 1D for single channel. `output` here is (N_output, n_channels).
    data = np.asarray(output, dtype=np.float64).T
    if settings.output_channels == 1:
        data = data[0]
    task.write(data, auto_start=False)

    return _NidaqmxTaskAdapter(task)

def setup_output_soundcard(settings):
    '''Open a soundcard `sd.OutputStream` for `acquisition.output_signal`.

    Clamps ``settings.output_channels`` against the output device's
    ``max_output_channels`` first (mutating ``settings`` in place via
    `_clamp_soundcard_output_channels`); without this clamp,
    ``sd.OutputStream`` would raise PortAudio ``-9998`` on a device
    that supports fewer output channels than requested.
    '''
    _clamp_soundcard_output_channels(settings)
    dtype = 'float32'

    output_stream = sd.OutputStream(samplerate=settings.output_fs,
                                  blocksize=settings.chunk_size,
                                  device=settings.output_device_index,
                                  channels=settings.output_channels,
                                  dtype=dtype,
                                  latency=None,
                                  extra_settings=None,
                                  callback=None,
                                  finished_callback=None,
                                  clip_off=None,
                                  dither_off=None,
                                  never_drop_input=None,
                                  prime_output_buffers_using_stream_callback=None)
    output_stream.start()
    return output_stream


#%% Mock backend — hardware-free, for tests
#
# Drop-in replacement for `Recorder` / `Recorder_NI_nidaqmx`. Used by
# `tests/test_acquisition_mock.py` to exercise the acquisition path
# (log_data, output_signal, stream_snapshot) on machines without a
# soundcard or NI-DAQmx driver. Selected via
# ``settings.device_driver='mock'``; see `start_stream`.
#
# No audio device is ever opened — `setup_output_mock` returns a
# no-op adapter, and `MockRecorder` synthesises a deterministic
# signal into its buffers at construction time. Tests can write
# directly to `stored_time_data` / `osc_time_data` after
# `start_stream` to inject a specific signal.


class MockRecorder(object):
    '''Hardware-free recorder. Same public attribute surface as
    `Recorder` / `Recorder_NI_nidaqmx` — `osc_time_data`,
    `stored_time_data`, `trigger_detected`, `audio_stream`,
    `init_stream`, `end_stream`, etc. — but does not touch any device.

    Buffers are filled with a deterministic sine-per-channel signal at
    construction so analysis-flow tests see non-trivial data. Tests
    that want a specific signal can overwrite `stored_time_data`
    directly after ``streams.start_stream`` and before `log_data`'s
    ``stored_time``-second sleep elapses.

    Trigger semantics: `trigger_detected` stays False unless a test
    sets it manually (no callback fires, since no real samples are
    arriving). The pretrigger path in `log_data` therefore always
    times out and takes the no-trigger fallback when driven via the
    mock — which is sufficient to test the timeout path itself.
    Successful-trigger flows belong on real hardware tests.
    '''

    def __init__(self, settings):
        self.settings = settings
        self.trigger_detected = False
        self.trigger_first_detected_message = False

        self.osc_time_axis = np.arange(
            0,
            (settings.num_chunks * settings.chunk_size) / settings.fs,
            1 / settings.fs,
        )
        self.osc_freq_axis = np.fft.rfftfreq(
            len(self.osc_time_axis), 1 / settings.fs,
        )
        self.osc_time_data = np.zeros(
            (settings.num_chunks * settings.chunk_size, settings.channels)
        )
        self.osc_time_data_windowed = np.zeros_like(self.osc_time_data)
        self.osc_freq_data = np.abs(np.fft.rfft(self.osc_time_data, axis=0))

        self.stored_num_chunks = 2 + int(
            np.ceil((settings.stored_time * settings.fs) / settings.chunk_size)
        )
        self.stored_time_data = np.zeros(
            (self.stored_num_chunks * settings.chunk_size, settings.channels)
        )
        self.stored_time_data_windowed = np.zeros_like(self.stored_time_data)
        self.stored_freq_data = np.abs(np.fft.rfft(self.stored_time_data, axis=0))

        # Deterministic signal: channel k gets a 0.1 V sine at
        # 100 * (k+1) Hz so tests can see distinct content per channel.
        t_stored = np.arange(self.stored_time_data.shape[0]) / settings.fs
        for ch in range(settings.channels):
            self.stored_time_data[:, ch] = 0.1 * np.sin(
                2 * np.pi * 100 * (ch + 1) * t_stored
            )
        # Fill osc_time_data with the same deterministic per-channel
        # sine (phase from t=0), synthesised on its own axis so the
        # osc buffer may be longer or shorter than the stored buffer.
        t_osc = np.arange(self.osc_time_data.shape[0]) / settings.fs
        for ch in range(settings.channels):
            self.osc_time_data[:, ch] = 0.1 * np.sin(
                2 * np.pi * 100 * (ch + 1) * t_osc
            )

        # Preserve `audio_stream` across re-__init__ calls the same way
        # `Recorder_NI_nidaqmx` does — log_data's pretrigger path calls
        # __init__(settings) to zero buffers but expects the stream
        # marker to survive.
        if not hasattr(self, 'audio_stream'):
            self.audio_stream = None

    def init_stream(self, settings, _input_=True, _output_=False):
        # Mark live with a sentinel so `streams.REC.audio_stream is
        # not None` (the test that gates the NI-task reuse path)
        # reads truthy.
        self.audio_stream = object()

    def end_stream(self):
        global REC
        REC = None
        self.audio_stream = None


class _MockOutputStream(object):
    '''No-op output stream matching the shape of both the soundcard
    (`sd.OutputStream`: `write` / `stop` / `close` / `start`) and the
    NI (`_NidaqmxTaskAdapter`: `StartTask` / `StopTask` /
    `WaitUntilTaskDone`) sides, so `acquisition.output_signal` and
    `log_data`'s cleanup branches work without touching real audio.'''

    def __init__(self, settings, output):
        self.settings = settings
        self.output = np.asarray(output)
        self.started = False

    # soundcard-side surface
    def write(self, data):
        pass

    def stop(self):
        pass

    def close(self):
        pass

    def start(self):
        pass

    # NI-side surface
    def StartTask(self):
        self.started = True

    def StopTask(self):
        self.started = False

    def WaitUntilTaskDone(self, timeout):
        pass

    def ClearTask(self):
        pass


def setup_output_mock(settings, output):
    '''Hardware-free analog-output stub used by `acquisition.output_signal`
    when ``settings.output_device_driver='mock'``.'''
    return _MockOutputStream(settings, output)